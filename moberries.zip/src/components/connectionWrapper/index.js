import React from 'react';
import { connect } from 'react-redux';
import { reduxForm } from 'redux-form';
// import validate from 'common/validations';

const ConnectionWrapper = (props) => {
  const {
    children,
    subscriptions
  } = props;

  return (
    React.Children.map(children, child => (
      React.cloneElement(child, {
        subscriptions,
      })
    ))
  );
};


export const DefaultForm = reduxForm({
  form: 'userSubscription',
  //validate,
  destroyOnUnmount: false,
})(ConnectionWrapper);

// const selector = formValueSelector('leadgen');

export const mapStateToProps = state => (
  {
    initialValues: state.user,
    subscriptions: state.subscriptions,
  }
);

// export const mapDispatchToProps = dispatch => ({
//   postToHydra: lead => dispatch(postToHydraAction(lead)),
//   changeLanguage: lang => dispatch(changeLanguageAction(lang)),
// });

export default connect(mapStateToProps)(DefaultForm);
