import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Field } from 'redux-form';
import Button from '@material-ui/core/Button';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import { ControlsButtonGroup } from '../controls/index';
import Switch from '@material-ui/core/Switch';
import Grid from '@material-ui/core/Grid';
import Divider from '@material-ui/core/Divider';
import Typography from '@material-ui/core/Typography';
import ConnectionWrapper from '../connectionWrapper';

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: theme.palette.background.paper,
  },
  button: {
    margin: theme.spacing(1),
  },
  section1: {
    margin: theme.spacing(3, 2),
  },
  section2: {
    margin: theme.spacing(2),
  },
  section3: {
    margin: theme.spacing(3, 1, 1),
  },
}));

const SubscriptionContent = (props) =>  {
  const classes = useStyles();
  const { subscriptions } = props;

  return (
    <div className={classes.root}>
      <div className={classes.section1}>
        <Grid container alignItems="center">
          <Grid item xs>
            <Typography gutterBottom variant="h4">
              Subscription
            </Typography>
          </Grid>
          <Grid item>
            <Typography gutterBottom variant="h6">
              $4.50
            </Typography>
          </Grid>
        </Grid>
        <Typography color="textSecondary" variant="body2">
          Please select subscription parameters:
        </Typography>
      </div>
      <Divider variant="middle" />
      <div className={classes.section2}>
        <Typography gutterBottom variant="body1">
          Month duration:
        </Typography>
        <div>
          <Field name="subscription.duration" component={ControlsButtonGroup} items={subscriptions.duration} className={classes.button} />
        </div>
      </div>
      <Divider variant="middle" />
      <div className={classes.section2}>
        <Typography gutterBottom variant="body1">
          Amount of gigabytes in a cloud:
        </Typography>
        <div>
          <Field name="subscription.gigabytes" component={ControlsButtonGroup} items={subscriptions.gigabytes} className={classes.button} />
        </div>
      </div>
      <Divider variant="middle" />
      <div className={classes.section2}>
        <Typography gutterBottom variant="body1">
          Upfront payment:
        </Typography>
        <div>
          <Switch
            checked={false}
          />
        </div>
      </div>

      <div className={classes.section3}>
        <Button color="primary">Add to cart</Button>
      </div>
    </div>
  );
};

const Subscription = () => (
  <ConnectionWrapper>
    <SubscriptionContent />
  </ConnectionWrapper>
)


export default Subscription;
