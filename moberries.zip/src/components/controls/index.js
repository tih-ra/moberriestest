import React from 'react';
import Button from '@material-ui/core/Button';

export const ControlsButtonGroup = (props) => {
  const { items, input, className } = props;

  return(
    items.map(item => (
      <Button onClick={() => input.onChange(item)} variant="outlined" className={className} color={item == input.value ? 'secondary' : 'primary'}  key={item}>{item}</Button>
    ))
  )
};
